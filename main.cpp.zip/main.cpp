#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip> 
using namespace std;

//struct that contains the bodies positions and velocities 
struct n_planets{
    //X and Y positions and velocity components
    double x, y, xdot, ydot; 
    //X and Y accelerations
    double xddot, yddot; 
    //Mass
    double mass; 
};
 
//Void function that calculates the X component of acceleration
//Distance is first calculated and then used in the accelleration formula
void Acc_X(n_planets *n_bodies, int other_body, int N){
    //Gravitaional constant
    const double G = 1; 
    n_bodies[other_body].xddot = 0;
    for(int j = 0; j < N; j++){
        if(j != other_body){
            double d = sqrt(pow((n_bodies[j].x - n_bodies[other_body].x),2) + pow((n_bodies[j].y - n_bodies[other_body].y),2));
            n_bodies[other_body].xddot += (G * n_bodies[j].mass / pow(d,3)) * (n_bodies[j].x - n_bodies[other_body].x);
        }
    }
}

//Void function that calculates the Y component of acceleration
//Distance is first calculated and then used in the accelleration formula 
void Acc_Y(n_planets *n_bodies, int other_body, int N){
    //Gravitaional constant
    const double G = 1; 
    n_bodies[other_body].yddot = 0;
    for(int j = 0; j < N; j++){
        if(j != other_body){
            double d = sqrt(pow((n_bodies[j].x - n_bodies[other_body].x),2) + pow((n_bodies[j].y - n_bodies[other_body].y),2));
            n_bodies[other_body].yddot += (G * n_bodies[j].mass / pow(d,3)) * (n_bodies[j].y - n_bodies[other_body].y);
        }
    }
}
 
//Function to intergrate the N body system with the Fourth Order Runge-Kutta
void Runge_Kutta(n_planets *n_bodies, int N, double delta_t){
    // For loop cycles through the number of bodies that has been stated in the main function
    for(int j = 0; j < N; j++){
        
        //Updates values of each body for every iteration of the numerical scheme
        Acc_X(n_bodies, j, N);
        Acc_Y(n_bodies, j, N);
        
        //Calculation of K1 terms of X and Y for each velocity and displacement component
        double k1_x = n_bodies[j].xdot * (delta_t); 
        double k1_y = n_bodies[j].ydot * (delta_t); 
        double k1_xdot = n_bodies[j].xddot * (delta_t); 
        double k1_ydot = n_bodies[j].yddot * (delta_t); 
 
        n_bodies[j].x += 0.5 * k1_x;
        n_bodies[j].y += 0.5 * k1_y;
        n_bodies[j].xdot += 0.5 * k1_xdot;
        n_bodies[j].ydot += 0.5 * k1_ydot;
        Acc_X(n_bodies, j, N);
        Acc_Y(n_bodies, j, N);
       
       
        //Calculation of K2 terms of X and Y for each velocity and displacement component
        double k2_x = n_bodies[j].xdot * (delta_t);
        double k2_y = n_bodies[j].ydot * (delta_t); 
        double k2_xdot = n_bodies[j].xddot * (delta_t); 
        double k2_ydot = n_bodies[j].yddot * (delta_t); 
        
        n_bodies[j].x += (-0.5 * k1_x) + (0.5 * k2_x);
        n_bodies[j].y += (-0.5 * k1_y) + (0.5 * k2_y);
        n_bodies[j].xdot += (-0.5 * k1_xdot) + (0.5 * k2_xdot);
        n_bodies[j].ydot += (-0.5 * k1_ydot) + (0.5 * k2_ydot);
        Acc_X(n_bodies, j, N);
        Acc_Y(n_bodies, j, N);

 
        //Calculation of K3 terms of X and Y for each velocity and displacement component
        double k3_x = n_bodies[j].xdot * (delta_t); 
        double k3_y = n_bodies[j].ydot * (delta_t); 
        double k3_xdot = n_bodies[j].xddot * (delta_t);
        double k3_ydot = n_bodies[j].yddot * (delta_t); 
        
        n_bodies[j].x += (-0.5 * k2_x) + k3_x;
        n_bodies[j].y += (-0.5 * k2_y) + k3_y;
        n_bodies[j].xdot += (-0.5 * k2_xdot) + k3_xdot;
        n_bodies[j].ydot += (-0.5 * k2_ydot) + k3_ydot;
        Acc_X(n_bodies, j, N);
        Acc_Y(n_bodies, j, N);
        
        
        //Calculation of K3 terms of X and Y for each velocity and displacement component
        double k4_x = n_bodies[j].xdot * (delta_t);
        double k4_y = n_bodies[j].ydot * (delta_t);
        double k4_xdot = n_bodies[j].xddot * (delta_t);
        double k4_ydot = n_bodies[j].yddot * (delta_t);
        
        n_bodies[j].x += -k3_x;
        n_bodies[j].y += -k3_y;
        n_bodies[j].xdot += -k3_xdot;
        n_bodies[j].ydot += -k3_ydot;
 
 
        //X and Y position and velocity components are updated
        n_bodies[j].x += (k1_x + 2*k2_x + 2*k3_x + k4_x)* (1.0/ 6.0);
        n_bodies[j].y += (k1_y + 2*k2_y + 2*k3_y + k4_y)* (1.0 / 6.0);
        n_bodies[j].xdot += (k1_xdot + 2*k2_xdot + 2*k3_xdot + k4_xdot)* (1.0/ 6.0);
        n_bodies[j].ydot += (k1_ydot + 2*k2_ydot + 2*k3_ydot + k4_ydot)* (1.0/ 6.0);
    }
}
 
int main(){
    //Time
    double T = 1;
    //Initial time
    double initial = 0;
    //Time step
    double delta_t = 0.01;
    //Final time
    double final = (T + delta_t);
    //Gravitational constant
    const double G = 1; 
    //Number of bodies in provided scenario
    int N = 3;
    n_planets n_bodies[N];
    
    //Set Body 1 initial values
    n_bodies[0].mass = 500.0;
    n_bodies[0].x = 0.0;
    n_bodies[0].y = 0.0;
    n_bodies[0].xdot = 0.0;
    n_bodies[0].ydot = 0.0;
    
    //Set Body 2 initial values
    n_bodies[1].mass = 1.0;
    n_bodies[1].x = 1.0;
    n_bodies[1].y = 0.0;
    n_bodies[1].xdot = 0.0;
    n_bodies[1].ydot = 25.0;
    
    //Body 3 initial values
    n_bodies[2].mass = 1.0;
    n_bodies[2].x = -1.0;
    n_bodies[2].y = 0.0;
    n_bodies[2].xdot = 0.0;
    n_bodies[2].ydot = -25.0;
    
    
    //Creating a parameters.txt file which will read required values
    ofstream readfile("parameters.txt");
    //Reading the constants of G, T and time step
    readfile << G << "\t " << T << " \t" << delta_t << " \n ";
    //Reading values to the parameters.txt file created, for a given number of N bodies
    for(int j = 0; j < N; j++){
        readfile << n_bodies[j].x << setw(10) << n_bodies[j].y<< setw(10) << n_bodies[j].xdot<< setw(10) << n_bodies[j].ydot << setw(10) << n_bodies[j].mass << endl;
    }
    //Clsing the parameters.txt file before opening/ creating the next file
    readfile.close();
    
    
    //Creating an output.txt file to print X and Y components of displacement and velocity values into
    //For cleane formatting
    ofstream outputfile("output.txt",ios::out|ios::trunc);
    //Precision is set to 4 significant figures
    outputfile.precision(4);
    
    //Using the Runge_Kutta function to perform a numerical intergrate the system
    //For loop is used to intergrate the system of N bodies using the numerical scheme
    for(double time = initial + delta_t; time <= final; time += delta_t){
        //Numerical integration of the system of N bodies using the function Runge_Kutta
        Runge_Kutta(n_bodies, N, delta_t);
        for (int j = 0; j < N; j++){
            //Printing the values of all bodies in a row for each timestep to the output.txt file
            outputfile << j << setw(15) << time << setw(15) << n_bodies[j].x << setw(15) << n_bodies[j].y << setw(15) << n_bodies[j].xdot << setw(15) << n_bodies[j].ydot << "\n";
        }
    }
    //Close output file once all values have been printed into output.txt
    outputfile.close();
    return 0;
}